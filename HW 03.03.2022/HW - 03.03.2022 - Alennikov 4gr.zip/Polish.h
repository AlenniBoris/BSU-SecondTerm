#ifndef HW_03_03_2022_POLISH_H
#define HW_03_03_2022_POLISH_H

#include "Stack.h"


bool Operation(char symb);

bool Numbers(char symb);

int Operation_Instr(int F_number, int S_Number, char type_Operation);

int Equation_instr(const std::string& equation_);


#endif //HW_03_03_2022_POLISH_H
